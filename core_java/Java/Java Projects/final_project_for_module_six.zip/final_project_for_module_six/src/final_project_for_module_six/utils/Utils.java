package final_project_for_module_six.utils;

import final_project_for_module_six.pojo.Department;
import final_project_for_module_six.pojo.Employee;
import final_project_for_module_six.pojo.Meeting;
import final_project_for_module_six.pojo.OfficeType;
import final_project_for_module_six.pojo.Position;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Utils {

    public static void writeToFile(String filename, Employee e) {
        File destFile = new File(filename + ".txt");
        try {
            if (destFile.exists() == false) {
                System.out.println("Needed to create one");
                destFile.createNewFile();
            }

            PrintWriter out = new PrintWriter(new FileWriter(destFile, true));
            out.append(e.getEmployeeId() + ", " + e.getEmployeeName() + ", " + e.getEmployeeEmail() + ", " + e.getDesignation() + ", " + e.getDepartment() + ", " + e.getEmployeeStatus() + ", " + e.getDescription() + "\n");
            out.close();
        } catch (IOException ex) {
            System.out.println("Could not logg!!!");
        }
    }

    ///////////////////////// MEETING ///////////////////////////////////
    public static void writeToFile(String filename, Meeting m) {
        File destFile = new File(filename + ".txt");
        try {
            if (destFile.exists() == false) {
                System.out.println("Needed to create one");
                destFile.createNewFile();
            }

            PrintWriter out = new PrintWriter(new FileWriter(destFile, true));
            out.append(m.getMeetingId() + ", " + m.getMeetingAgenda() + ", " + m.getDetails() + ", " + m.getMeetinPlace() + ", " + m.getAttendees() + ", " + m.getCalledBy() + ", " + m.getOfficeName() + ", " + m.getSetMeetingDate() + ", " + m.getSetMeetingTime() + ", " + m.getMeetingDuration() + ", " + m.getMeetingStatus() + ", " + m.getMeetingCreatedDateTime() + ", " + "\n");
            out.close();
        } catch (IOException ex) {
            System.out.println("Could not logg!!!");
        }
    }



   
    
    
    public static void readDataFromFile(String filename, DefaultTableModel model) {
        String line;
        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader(filename + ".txt"));
            while ((line = reader.readLine()) != null) {
                model.addRow(line.split(", "));
            }
            reader.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Buffered reader issue");
        }
    }

}
