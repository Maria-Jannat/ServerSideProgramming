package final_project_for_module_six.serviceImplementation;

import final_project_for_module_six.connection.DatabaseConnection;
import final_project_for_module_six.pojo.Employee;
import final_project_for_module_six.pojo.MeetingCancel;
import final_project_for_module_six.pojo.Office;
import final_project_for_module_six.service.CommonServiceAdapter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MeetingCancelServiceImplementation extends CommonServiceAdapter<MeetingCancel> {

    static Connection conn = DatabaseConnection.getInstance();

    @Override
    public void createTable() {
        String sql = "create table meeting_cancel (meeting_status varchar(50) not null)";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.execute();
            System.out.println(":::::: Table Created. Evet ::::::");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void save(MeetingCancel t) {
        String sql = "insert into meeting_cancel(meeting_status) values(?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, t.getMeetingStatus());
            ps.executeUpdate();
            System.out.println("::::: Data Inserted Successfully :::::");
        } catch (SQLException ex) {
            Logger.getLogger(MeetingCancelServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(MeetingCancel t) {
        String sql = "update meeting_cancel set meeting_status = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, t.getMeetingStatus());
            ps.executeUpdate();
            System.out.println("::::: Data Updated Successfully :::::");
        } catch (SQLException ex) {
            Logger.getLogger(MeetingCancelServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//
//    @Override
//    public void delete(int Meeting_Id) {
//        String sql = "delete from meeting where Meeting_Id = ?";
//        try {
//            PreparedStatement ps = conn.prepareStatement(sql);
//            ps.setInt(1, Meeting_Id);
//            ps.executeUpdate();
//        } catch (SQLException ex) {
//            Logger.getLogger(MeetingCancelServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//    @Override
//    public MeetingCancel get(int Id) {
//        MeetingCancel meeting = null;
//        String sql = "select * from meeting_cancel where Id = ?";
//        try {
//            PreparedStatement ps = conn.prepareStatement(sql);
//            ps.setInt(1, Id);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {  
//                meeting = new MeetingCancel(rs.getString("meeting_status"));
//            }
//        } catch (SQLException ex) {
//            Logger.getLogger(MeetingCancelServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return meeting;
//    }
//
    @Override
    public List<MeetingCancel> getList() {
        List<MeetingCancel> meetings = new ArrayList<>();
        String sql = "select * from meeting_cancel";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MeetingCancel meeting = new MeetingCancel(rs.getString("meeting_status"));
                meetings.add(meeting);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MeetingCancelServiceImplementation.class.getName()).log(Level.SEVERE, null, ex);
        }
        return meetings;
    }

    @Override
    public MeetingCancel getByName(String name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MeetingCancel getPositionByPostId(int Position_Id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MeetingCancel getDepartmentByDeptId(int Department_Id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public MeetingCancel getEmployeeByEmpId(int Employee_Id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
